The data format of these files is:

TSV (Tab-Separated Values)
- the file encoding is UTF-16LE (Unicode UTF-16 Litte Ending with byte order marker)
- the used line ending is \r\n (Windows)
- first line contains the names of the columns (header)
- columns are delimited by \t (TAB)
